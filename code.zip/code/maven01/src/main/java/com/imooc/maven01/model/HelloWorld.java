package com.imooc.maven01.model;

public class HelloWorld {
	public String sayHello() {
		return "Hello World!";
	
	}

}